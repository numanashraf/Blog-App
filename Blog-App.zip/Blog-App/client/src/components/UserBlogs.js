import React, { useEffect, useState } from "react";
import axios from "axios";
import Blog from "./Blog";

function UserBlogs() {
  const [user, setUser] = useState();
  const id = localStorage.getItem("userId");
  const sendRequest = async () => {
    const res = await axios.get(`http://localhost:8000/api/blog`);
    // console.log(res.data.blogs);
    setUser(res.data.blogs);
    console.log(user);
  };
  useEffect(() => {
    sendRequest();
  }, []);

  return (
    <div>
      {user &&
        user
          .filter((blog) => blog.user === id)
          .map((blog, index) => (
            <Blog
              id={blog._id}
              key={index}
              isUser={true}
              title={blog.title}
              content={blog.content}
              image={blog.image}
              user={blog.user}
            />
          ))}
    </div>
  );
}

export default UserBlogs;
