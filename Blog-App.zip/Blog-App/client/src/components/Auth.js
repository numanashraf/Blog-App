import React, { useState } from "react";
import axios from "axios";
import { useDispatch } from "react-redux";
import { authActions } from "../store";
import { useNavigate } from "react-router-dom";

const Auth = () => {
  const navigate = useNavigate();

  const dispatch = useDispatch();
  const [inputs, setInputs] = useState({
    name: "",
    email: "",
    password: "",
  });
  const [isSignup, setIsSignup] = useState(false);

  const handleChange = (event) => {
    setInputs((prevValue) => ({
      ...prevValue,
      [event.target.name]: event.target.value,
    }));
  };

  const sendRequest = async (type = "signin") => {
    const res = await axios
      .post(`http://localhost:8000/api/user/${type}`, {
        name: inputs.name,
        email: inputs.email,
        password: inputs.password,
      })
      .catch((err) => console.log(err));

    const data = await res.data;
    return data;
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    if (isSignup) {
      sendRequest("signup")
        .then((data) => localStorage.setItem("userId", data.user._id))
        .then(() => {
          dispatch(authActions.signin());
        })
        .then(() => {
          navigate("/");
        })
        .then((data) => console.log(data));
    } else {
      sendRequest()
        .then((data) => localStorage.setItem("userId", data.user._id))
        .then(() => {
          dispatch(authActions.signin());
        })
        .then(() => {
          navigate("/");
        })
        .then((data) => console.log(data));
    }
  };

  return (
    <div>
<form onSubmit={handleSubmit}>
      <div className="container">
        <div className="row justify-content-center mt-5">
          <div className="col-lg-4">
            <div className="card shadow">
              <div className="card-body">
                <h3 className="text-center mb-4">{isSignup ? 'Sign Up' : 'Sign In'}</h3>
                {isSignup && (
                  <div className="mb-3">
                    <input
                      className="form-control"
                      name="name"
                      onChange={handleChange}
                      placeholder="Name"
                      value={inputs.name}
                    />
                  </div>
                )}
                <div className="mb-3">
                  <input
                    className="form-control"
                    name="email"
                    onChange={handleChange}
                    type="email"
                    value={inputs.email}
                    placeholder="Email"
                  />
                </div>
                <div className="mb-3">
                  <input
                    className="form-control"
                    name="password"
                    onChange={handleChange}
                    type="password"
                    value={inputs.password}
                    placeholder="Password"
                  />
                </div>
                <div className="text-center">
                <button
                  type="submit"
                  className="btn btn-warning btn-block "
                >
                  {isSignup ? 'Create Account' : 'Sign In'}
                </button>
                <br></br>
                <button
                  type="button"
                  className="btn btn-warning btn-block mt-2"
                  onClick={() => setIsSignup(!isSignup)}
                >
                  {isSignup ? 'Have an Account? Sign In' : 'New User? Register Now'}
                </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>


    </div>
  );
};

export default Auth;
