import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const labelStyle = { mb: 1, mt: 2, fontSize: "24px", fontWeight: "bold" };

const AddBlog = () => {
  const navigate = useNavigate();
  const [inputs, setInputs] = useState({
    title: "",
    content: "",
    image: "",
  });

  const handleChange = (event) => {
    setInputs((prevValue) => ({
      ...prevValue,
      [event.target.name]: event.target.value,
    }));
  };

  const sendRequest = async () => {
    try {
      const response = await axios.post("http://localhost:8000/api/blog/add", {
        title: inputs.title,
        content: inputs.content,
        image: inputs.image,
        user: localStorage.getItem("userId"),
      });
      return response.data;
    } catch (error) {
      console.error(error);
      throw error; 
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    sendRequest()
      .then((data) => console.log(data))
      .then(() => navigate("/"));
  };

  return (
    <div>

<form onSubmit={handleSubmit}>
      <div className="container">
        <div className="row justify-content-center mt-5">
          <div className="col-lg-8 col-md-10">
            <div className="card border-secondary rounded shadow">
              <div className="card-body">
                <h3 className="text-center mb-4">Create your Blog</h3>
                <div className="mb-3">
                  <label htmlFor="title" className="form-label">
                    Title
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    name="title"
                    onChange={handleChange}
                    value={inputs.title}
                    id="title"
                  />
                </div>
                <div className="mb-3">
                  <label htmlFor="content" className="form-label">
                    Content
                  </label>
                  <textarea
                    className="form-control"
                    name="content"
                    onChange={handleChange}
                    value={inputs.content}
                    id="content"
                    rows="4"
                  ></textarea>
                </div>
                <div className="mb-3">
                  <label htmlFor="image" className="form-label">
                    Image URL
                  </label>
                  <input
                    type="text"
                    className="form-control"
                    name="image"
                    onChange={handleChange}
                    value={inputs.image}
                    id="image"
                  />
                </div>
                <button
                  type="submit"
                  className="btn btn-warning btn-block"
                >
                  Submit Blog
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </form>


    </div>
  );
};

export default AddBlog;
