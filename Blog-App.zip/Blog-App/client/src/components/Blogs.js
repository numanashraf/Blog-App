import React, { useEffect, useState } from "react";
import axios from "axios";
import Blog from "./Blog";

function Blogs() {
  const [blogs, setBlogs] = useState();
  const sendRequest = async () => {
    const res = await axios.get("http://localhost:8000/api/blog/");

    console.log(res);
    setBlogs(res.data.blogs);
    console.log(blogs);
  };
  useEffect(() => {
    sendRequest();
  }, []);

  return (
    <div>
      {blogs &&
        blogs.map((blog, index) => (
          <Blog
            id={blog._id}
            // isUser={localStorage.getItem("userId") === blog.user._id}
            title={blog.title}
            content={blog.content}
            image={blog.image}
          />
        ))}
     
    </div>
  );
}

export default Blogs;
