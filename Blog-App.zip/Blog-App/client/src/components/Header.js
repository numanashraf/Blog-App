import React, { useState } from "react";
import { Link } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { authActions } from "../store";
import blogpost from './assets/blogpost.png';

function Header() {
  const dispatch = useDispatch();
  const isLoggedIn = useSelector((state) => state.isLoggedIn);
  const [value, setValue] = useState();
  return (

    <nav className="navbar navbar-expand-lg navbar-light" style={{ background: "linear-gradient(90deg, rgba(240,13,205,1) 0%, rgba(0,212,255,1) 100%)" }}>
    <div className="container">
      <Link className="navbar-brand font-weight-bold " to="/"><img src={blogpost} style={{ width: '200px', height: '100px' }}></img></Link>
      <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="navbarNav">
        <ul className="navbar-nav ms-auto">
          {isLoggedIn && (
            <>
              <li className="nav-item">
                <Link className="nav-link font-weight-bold" to="/"><b>ALL BLOGS</b></Link>
              </li>
              <li className="nav-item">
                <Link className="nav-link font-weight-bold" to="/myBlogs"><b>MY BLOGS</b></Link>
              </li>
              <li className="nav-item ">
                <Link className="nav-link font-weight-bold" to="/blogs/add"><b>CREATE BLOGS</b></Link>
              </li>
            </>
          )}
        </ul>
        <ul className="navbar-nav ms-auto">
          {!isLoggedIn ? (
            <>
              <li className="nav-item">
                <Link className="btn btn-primary me-2" to="/auth">Sign In</Link>
              </li>
              <li className="nav-item">
                <Link className="btn btn-primary" to="/auth">Sign Up</Link>
              </li>
            </>
          ) : (
            <li className="nav-item">
              <button className="btn btn-primary" onClick={() => dispatch(authActions.logout())}>Log Out</button>
            </li>
          )}
        </ul>
      </div>
    </div>
  </nav>

  );
}

export default Header;
