import mongoose from "mongoose";
import Blog from "../model/Blog.js";
import User from "../model/User.js";

export const getAllBlogs = async (req, res, next) => {
  let blogs;

  try {
    blogs = await Blog.find();
  } catch (error) {
    console.log(error);
  }
  if (!blogs) {
    return res.status(404).json({ message: "No Blog Found!" });
  }
  return res.status(200).json({ blogs });
};

export const addBlog = async (req, res, next) => {
  const { title, content, image, user } = req.body;

  const blog = new Blog({
    title,
    content,
    image,
    user,
  });

  try {
    const savedBlog = await blog.save();
    res.status(200).json({
      success: true,
      message: "Blog saved successfully",
      blog: savedBlog,
    });
  } catch (error) {
    console.log(error);
    res.status(500).json({
      success: false,
      message: "Unable to save blog",
      error: error.message,
    });
  }
};

export const updateBlog = async (req, res, next) => {
  const { title, content, image } = req.body;

  const blogId = req.params.id;

  try {
    const updatedBlog = await Blog.findByIdAndUpdate(
      blogId,
      {
        title,
        content,
        image,
      },
      { new: true }
    );
    if (!updatedBlog) {
      return res.status(500).json({ message: "Unable to update blog" });
    }
    return res.status(200).json({ blog: updatedBlog });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Unable to update blog", error });
  }
};

export const getBlogById = async (req, res, next) => {
  const id = req.params.id;

  let blog;
  try {
    blog = await Blog.findById(id);
  } catch (error) {
    return console.log(error);
  }
  if (!blog) {
    return res.status(404).json({ message: "No blog found!" });
  }
  return res.status(200).json({ blog });
};

export const deleteBlog = async (req, res, next) => {
  const blogId = req.params.id;

  try {
    const deletedBlog = await Blog.findByIdAndRemove(blogId);
    if (!deletedBlog) {
      return res.status(500).json({ message: "Unable to delete blog" });
    }
    return res.status(200).json({ message: "Blog deleted successfully" });
  } catch (error) {
    console.log(error);
    return res.status(500).json({ message: "Unable to delete blog", error });
  }
};

export const getUserById = async (req, res, next) => {
  let userBlogs;
  try {
    userBlogs = await User.findById(req.params.id).populate("blogs");
  } catch (error) {
    console.log(error);
  }
  if (!userBlogs) {
    return res.status(400).json({ message: "No blogs found!" });
  }
  return res.status(200).json({ user: userBlogs });
};
